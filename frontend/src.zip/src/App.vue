<template>
  <!-- Fullscreen Standalone View untuk Halaman Login / Auth (Tanpa Dashboard) -->
  <div v-if="isAuthPage" class="min-h-screen">
    <router-view />
  </div>

  <!-- Dashboard Shell Utama (Hanya Tampil Saat Pengguna Berada di Dashboard) -->
  <div v-else class="bg-slate-50 flex" :class="isDokterPage ? 'h-screen overflow-hidden' : 'min-h-screen'">
    <!-- 1. Left Desktop Sidebar Navigation -->
    <WebSidebar />

    <!-- 2. Main Content Canvas -->
    <div class="flex-1 flex flex-col min-w-0" :class="{ 'h-screen overflow-hidden': isDokterPage }">
      <!-- Top Contextual Bar -->
      <WebTopBar />

      <!-- Main Router Canvas -->
      <main
        class="flex-1 w-full mx-auto min-h-0"
        :class="isDokterPage ? 'max-w-none p-0 overflow-hidden flex flex-col' : 'max-w-[1600px] p-4 md:p-6 lg:p-8 pb-28 md:pb-12'"
      >
        <router-view />
      </main>
    </div>

    <!-- 3. Mobile Bottom Navigation (Khusus Layar HP) -->
    <BottomNav class="md:hidden" />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { syncUserProfile } from '@/services/userState';
import WebSidebar from '@/components/WebSidebar.vue';
import WebTopBar from '@/components/WebTopBar.vue';
import BottomNav from '@/components/BottomNav.vue';

const route = useRoute();
const isAuthPage = computed(() => route.path === '/login');
const isDokterPage = computed(() => route.path === '/dokter');

onMounted(() => {
  syncUserProfile();
});
</script>
